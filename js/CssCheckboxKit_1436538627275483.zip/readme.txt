CSS CHECKBOX - README AND INSTALLATION GUIDE - www.csscheckbox.com
1. Open the included file 'style.css' and copy the CSS code into your own stylesheet
2. Change the classes of your HTML Text Boxes to 'css-input'
Refer to the included file 'demo.html' for HTML samples and syntax.